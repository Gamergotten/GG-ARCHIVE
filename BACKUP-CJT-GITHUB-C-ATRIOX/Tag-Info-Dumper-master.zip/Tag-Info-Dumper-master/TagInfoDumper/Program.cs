﻿using System.Diagnostics;
using System.Text;

namespace TagInfoDumper
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Checks if the directory provided exists.
            if (Directory.Exists(args[0]))
                DumpTags(args[0]); // Dumps tags

            // TESTING
            //Console.WriteLine("Press [ENTER] to start...");
            //Console.ReadKey();
            //List<string> GamePaths = new()
            //{
            //    @"C:\Program Files (x86)\Steam\steamapps\common\Halo Infinite",
            //    @"X:\Games\Halo Infinite - Big Forge",
            //    @"X:\Games\Halo Infinite - Lumu",
            //    @"X:\Games\Halo Infinite - Feburary Flight\Halo Infinite - Biggest"
            //};

            //foreach (string GamePath in GamePaths)
            //    DumpTags(GamePath);
        }

        static Dictionary<string, string> tags = new(); // Key = TagID, Value = Output String
        static Queue<string> modulePaths = new();
        static int compModules = 0;
        static int moduleCount = 0;

        static void DumpTags(string path)
        {
            compModules = 0;
            Stopwatch sw = new();
            sw.Start();
            // Set Output File
            string outputFile = @$"{Directory.GetCurrentDirectory()}\Plugins\tagnames.txt";
            Console.WriteLine($"Game Path: {path}");
            Console.WriteLine($"Output File: {outputFile}");

            // Get module paths
            Console.WriteLine($"Searching for modules...");
            GetModules(path + "\\deploy");
            moduleCount = modulePaths.Count();
            Console.WriteLine($"Module Count: {modulePaths.Count}");

            // Check for existing output file
            if (File.Exists(outputFile))
            {
                Console.WriteLine($"Reading saved tag data...");
                tags = InhaleTags(outputFile);
                Console.WriteLine($"Current tag count: {tags.Count}");
            }

            while (modulePaths.Count > 0)
            {
                // Load the module
                string modulePath = modulePaths.Dequeue();
                Module m = new(modulePath);

                // Iterate through tag entries
                int count = 0;
                foreach (KeyValuePair<string, string> kvp in m.TagList)
                {
                    // Check Tag ID
                    string tagID = kvp.Key;
                    if (!tags.ContainsKey(tagID) && tagID != "FFFFFFFF" && tagID != "00000000")
                    {
                        // Add tag to list
                        tags.Add(tagID, kvp.Value);
                        count++;
                    }
                }

                compModules++;
                Console.WriteLine($"{compModules}/{moduleCount} ({Math.Round((Decimal)compModules / moduleCount * 100, 2)}%): {modulePath.Split(@"\deploy").Last()}: Found {count} new tags!");
            }

            // Create List and sort for writing out.
            Console.WriteLine($"Creating output file...");
            List<string> outLines = new List<string>(tags.Values).OrderBy(name => name.Split(":")[4]).ThenBy(name => name.Split(":")[3]).ToList();
            
            // Check for pre-existing file and delete it.
            if (File.Exists(outputFile))
                File.Delete(outputFile);
           

            // Write out
            File.WriteAllLines(outputFile,outLines);
            sw.Stop();
            Console.WriteLine($"Done! Found {tags.Count()} tags in {sw.Elapsed.Seconds} seconds!");
        }

        static Dictionary<string, string> InhaleTags(string path)
        {
            Dictionary<string, string> result = new();
            foreach (string line in File.ReadAllLines(path))
            {
                string tagID = line.Split(':')[0].Trim();
                if (!result.ContainsKey(tagID) && tagID != "")
                    result.Add(tagID, line);  
            }
            return result;
        }

        static void GetModules(string path)
        {
            foreach (string fo in Directory.GetDirectories(path))
            {
                foreach (string fi in Directory.GetFiles(fo))
                    if (fi.EndsWith(".module"))
                        modulePaths.Enqueue(fi);

                if (Directory.GetDirectories(fo).Count() > 0)
                    GetModules(fo);
            }
        }
    }

    public class Module
    {
        public static string FilePath = "";
        private static FileStream? ModuleStream { get; set; }
        public static int stringOffset { get; set; }
        private int fileCount { get; set; }
        private static int stringSize { get; set; }
        private string version { get; set; }
        public Dictionary<string, string> TagList = new();

        public Module(string modulePath)
        {
            FilePath = modulePath;
            ModuleStream = new FileStream(FilePath, FileMode.Open);

            fileCount = BitConverter.ToInt32(GetBytes(4, 16));
            stringSize = BitConverter.ToInt32(GetBytes(4, 36));
            version = Encoding.ASCII.GetString(GetBytes(5, 0));
            stringOffset = 80 + (88 * fileCount);

            for (int i = 0; i < fileCount; i++)
            {
                TagInfo? ti;

                if (version == "mohd5")
                    ti = new(GetBytes(88, 72 + (88 * i)), false);
                else
                    ti = new(GetBytes(88, 72 + (88 * i)), true);

                if (!TagList.ContainsKey(ti.TagID) && ti.TagID != "FFFFFFFF" && ti.TagID != "00000000" && ti.TagID != "BCBCBCBC")
                    TagList.Add(ti.TagID, ti.GetString());
            }

            ModuleStream.Close();
        }

        public class TagInfo
        {
            public TagInfo(byte[] buffer, bool stringsExist)
            {
                TagID = Convert.ToHexString(buffer, 40, 4);
                AssetID = Convert.ToHexString(buffer, 80, 8);
                TagType = ReverseString(Encoding.ASCII.GetString(buffer[20..24]));

                if (stringsExist)
                    Name = GetNullTerminatedString(stringOffset + BitConverter.ToInt32(buffer, 64), stringSize).Trim('\0');
                else
                    Name = $"Object ID: {TagID}";
            }

            public string GetString()
            {
                // IRTV Dump
                //return $"{TagID.Trim()} : {Name.Trim()}";

                // General Dump
                return $"{TagID.Trim()} : {AssetID.Trim()} : {FilePath.Split(@"\deploy\").Last().Trim()} : {Name.Trim()} : {TagType.Trim()}";
            }

            public string TagID { get; set; }
            public string AssetID { get; set; }
            public string Name { get; set; }
            public string TagType { get; set; }
        }

        private static string GetNullTerminatedString(int offset, int maxSize)
        {
            ModuleStream.Position = offset;
            List<byte> byteList = new();
            for (int i = 0; i < maxSize; i++)
            {
                byte newByte = (byte)ModuleStream.ReadByte();
                if (newByte == 0)
                    break;
                else
                    byteList.Add(newByte);
            }
            return Encoding.ASCII.GetString(byteList.ToArray(), 0, byteList.Count());
        }

        private byte[] GetBytes(int size, int offset)
        {
            ModuleStream.Position = offset;
            byte[] buffer = new byte[size];
            ModuleStream.Read(buffer);
            return buffer;
        }

        public static string ReverseString(string myStr)
        {
            char[] myArr = myStr.ToCharArray();
            Array.Reverse(myArr);
            return new string(myArr);
        }
    }
}