﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Navigation;
using System.Windows.Threading;

namespace Infinite_Modding_Tool
{
    public partial class MainWindow : Window
    {
        #region Window Controls
        // This section is just for basic window events.
        private void CommandBinding_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }

        private void CommandBinding_Executed_Minimize(object sender, ExecutedRoutedEventArgs e)
        {
            SystemCommands.MinimizeWindow(this);
        }

        private void CommandBinding_Executed_Maximize(object sender, ExecutedRoutedEventArgs e)
        {
            SystemCommands.MaximizeWindow(this);
            RestoreButton.Visibility = Visibility.Visible;
            MaximizeButton.Visibility = Visibility.Collapsed;
        }

        private void CommandBinding_Executed_Restore(object sender, ExecutedRoutedEventArgs e)
        {
            SystemCommands.RestoreWindow(this);
            RestoreButton.Visibility = Visibility.Collapsed;
            MaximizeButton.Visibility = Visibility.Visible;
        }

        private void CommandBinding_Executed_Close(object sender, ExecutedRoutedEventArgs e)
        {
            ForceCloseAll();
            SystemCommands.CloseWindow(this);
        }

        private void Move_Window(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }

        private void OpenHyperlink(object sender, RequestNavigateEventArgs e)
        {
            Process.Start(new ProcessStartInfo(e.Uri.AbsoluteUri) { UseShellExecute = true });
            e.Handled = true;
        }
        #endregion

        #region Initialization
        public MainWindow()
        {
            InitializeComponent();
            DataContext = this; // Used for binding data

            // Button Events - Formatted like this for simplification (Probably a better way.)
            SendButton.Click += (sender, args) => SendCommand(CommandInput.Text);
            ForceCloseButton.Click += (sender, args) => ForceCloseAll();
            ClearButton.Click += (sender, args) => Output.Text = "";
        }
        #endregion

        #region Process Handling
        List<Process> curProcs = new();

        private void RunExecutable(string path, string arguments = "", bool continuousOutput = true)
        {
            try
            {
                // Create a new process
                Process p = new Process();
                string procName = path.Split("\\").Last();

                // Set start info
                p.StartInfo.UseShellExecute = false;
                p.StartInfo.Arguments = arguments;
                p.StartInfo.RedirectStandardOutput = true;
                p.StartInfo.RedirectStandardError = true;
                p.StartInfo.FileName = path;
                p.StartInfo.CreateNoWindow = true;
                p.Exited += new EventHandler(ProcessExited);

                // Handle output events
                if (continuousOutput)
                {
                    // If we are continously reading the ouptut, use these functions to send to our console.
                    p.OutputDataReceived += (sender, args) => SendToConsole(args.Data);
                    p.ErrorDataReceived += (sender, args) => SendToConsole(args.Data);
                }

                // Start process
                p.Start();
                
                SendToConsole($"Process Started: ({p.Id}) {procName}");

                if (continuousOutput) 
                {
                    // This starts the reading of the program and outputs it to our fake console.
                    p.BeginOutputReadLine();
                    p.BeginErrorReadLine();
                }
                else
                {
                    SendToConsole(p.StandardOutput.ReadToEnd()); // If we aren't, write to console once we are done.
                }

                // Return Process
                p.WaitForExitAsync();
                curProcs.Add(p);
            }
            catch (Exception ex)
            {
                SendToConsole($"Error Starting Process: {ex.Message}");
            }
        }

        private void ProcessExited(object? sender, EventArgs? e)
        {
            // Used for handling what happens when a process ends. 
            if (sender != null)
            {
                Process p = (Process)sender;
                string procName = p.StartInfo.FileName.Split("\\").Last();
                SendToConsole($"Process Closed: ({p.Id}) {procName}");
                curProcs.Remove(p);
            }
        }

        private void ForceCloseAll()
        {
            // Closes each running process. This occurs when this program closes as well.
            foreach (Process curProc in curProcs)
                curProc.Kill();

            curProcs.Clear();
            SendToConsole("All Processes Closed!");
        }
        #endregion

        #region Console
        private void SendCommand(string command)
        {
            // This will need to change in order to handle things withing "".
            string[] args = command.Split(" ");
            string file = $@".\Plugins\{args[0]}.exe";

            if (File.Exists(file))
                RunExecutable(file, command.Split(args[0]).Last());
            else
                SendToConsole($"Command Not Recognized: {command}");
        }

        private void SendToConsole(string? message)
        {
            if (message != null)
            {
                Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() => Output.Text += (message + "\n")));
                Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() => Output.ScrollToEnd()));
            }
        }
        #endregion

        #region Tests
        private void TestRun(object sender, RoutedEventArgs e)
        {
            string file = @".\Plugins\TagDumper.exe";
            string path = @"D:\Programs\Steam\steamapps\common\Halo Infinite";
            RunExecutable(file, $"\"{path}\"", true);
        }
        #endregion
    }
}
