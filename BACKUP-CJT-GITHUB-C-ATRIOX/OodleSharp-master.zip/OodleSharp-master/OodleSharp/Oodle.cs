using System;
using System.Runtime.InteropServices;

namespace OodleSharp
{
    public unsafe static class Oodle
    {
        [DllImport("oo2core_8_win64.dll")]
        private static extern int OodleLZ_Compress(OodleFormat format, byte[] buffer, long bufferSize, byte[] outputBuffer, OodleCompressionLevel level, uint options, uint offs, uint unk, byte[] scratchBuffer, uint scratchBufferSize);

        [DllImport("oo2core_8_win64.dll")]
        //private static extern int OodleLZ_Decompress(byte* buffer, long bufferSize, byte* outputBuffer, long outputBufferSize, uint a, uint b, ulong c, uint d, uint e, uint f, uint g, uint h, uint i, uint threadModule);
        //private static extern int OodleLZ_Decompress(byte* buffer, int bufferSize, byte* outputBuffer, int outputBufferSize, int a, int b, int c, void* d, void* e, void* f, void* g, void* h, void* i, int threadModule);
        static extern unsafe long OodleLZ_Decompress(byte* compBuf, long compBufSize, byte* rawBuf, long rawLen, OodleLZ_FuzzSafe fuzzSafe = OodleLZ_FuzzSafe.OodleLZ_FuzzSafe_Yes, OodleLZ_CheckCRC checkCRC = OodleLZ_CheckCRC.OodleLZ_CheckCRC_No, OodleLZ_Verbosity verbosity = OodleLZ_Verbosity.OodleLZ_Verbosity_None, byte* decBufBase = null, long decBufSize = 0, long fpCallback = 0, long callbackUserData = 0, byte* decoderMemory = null, long decoderMemorySize = 0, OodleLZ_Decode_ThreadPhase threadPhase = OodleLZ_Decode_ThreadPhase.OodleLZ_Decode_Unthreaded);


        // 'OO_SINTa' shall be 'long' for the time being
        /*private static extern int OodleLZ_Decompress(void* compBuf,
                             long compBufSize,
                             void* rawBuf,
                             long rawLen,
                             OodleLZ_FuzzSafe fuzzSafe = OodleLZ_FuzzSafe.OodleLZ_FuzzSafe_Yes,
                             OodleLZ_CheckCRC checkCRC = OodleLZ_CheckCRC.OodleLZ_CheckCRC_No,
                             OodleLZ_Verbosity verbosity = OodleLZ_Verbosity.OodleLZ_Verbosity_None,
                             void* decBufBase = null,
                             long decBufSize = 0,
                             void* fpCallback = null, // OodleDecompressCallback
                             void* callbackUserData = null,
                             void* decoderMemory = null,
                             long decoderMemorySize = 0,
                             OodleLZ_Decode_ThreadPhase threadPhase = OodleLZ_Decode_ThreadPhase.OodleLZ_Decode_Unthreaded);
        */


        public static byte[] Compress(byte[] buffer, OodleFormat format, OodleCompressionLevel level){
            byte[] skBuffer = new byte[0];
            uint skBufferSize = (uint)skBuffer.Length;
            uint compressedBufferSize = GetCompressionBound((uint)buffer.Length);
            byte[] compressedBuffer = new byte[compressedBufferSize];

            int compressedCount = OodleLZ_Compress(format, buffer, buffer.Length, compressedBuffer, level, 0, 0, 0, skBuffer, skBufferSize);

            byte[] outputBuffer = new byte[compressedCount];
            Buffer.BlockCopy(compressedBuffer, 0, outputBuffer, 0, compressedCount);

            return outputBuffer;
        }

        public static byte[] Decompress(byte[] buffer, int size, int uncompressedSize){
            byte[] decompressedBuffer = new byte[uncompressedSize];

            //int decompressedCount = OodleLZ_Decompress(array_to_ptr(buffer), size, array_to_ptr(decompressedBuffer), uncompressedSize);
            //int decompressedCount = OodleLZ_Decompress(array_to_ptr(buffer), size, array_to_ptr(decompressedBuffer), uncompressedSize, 0, 0, 0, null, 0, null, null, null, 0, OodleLZ_Decode_ThreadPhase.OodleLZ_Decode_ThreadPhaseAll);

            //int decompressedCount = OodleLZ_Decompress(array_to_ptr(buffer), size, array_to_ptr(decompressedBuffer), uncompressedSize, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3);
            long decompressedCount = OodleLZ_Decompress(array_to_ptr(buffer), size, array_to_ptr(decompressedBuffer), uncompressedSize);

            if (decompressedCount == uncompressedSize)
                return decompressedBuffer;
            else if (decompressedCount == 0)
                throw new Exception("Error decompressing: output was 0 bytes, indicating failure");
            else if (decompressedCount < uncompressedSize)
                throw new Exception("Error decompressing: output was less than uncompressed size");
            else throw new Exception("Error decompressing: output exceeded uncompressed size");
        }
        private static unsafe byte* array_to_ptr(byte[] array){
            fixed (byte* ptr = &array[0]) {
                return ptr;
            }
        }
        private static uint GetCompressionBound(uint bufferSize)
        {
            return bufferSize + 274 * ((bufferSize + 0x3FFFF) / 0x40000);
        }

        /*private static uint GetDecompressionBound(uint bufferSize)
        {
            uint v2 = bufferSize + 272 + 0;
            uint v3 = (bufferSize + 0x3FFFF) / 0x40000;
            if (bufferSize + 16731 + 2 * v3 < v2)
            {
                v2 = bufferSize + 16731 + 2 * v3;
            }
            return v2;
        }*/
    }
}
