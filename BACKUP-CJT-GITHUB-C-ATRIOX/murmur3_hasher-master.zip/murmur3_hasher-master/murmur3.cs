﻿/*
This code is public domain.
The MurmurHash3 algorithm was created by Austin Appleby and put into the public domain.  See http://code.google.com/p/smhasher/
This C# variant was authored by
Elliott B. Edwards and was placed into the public domain as a gist
Status...Working on verification (Test Suite)
Set up to run as a LinqPad (linqpad.net) script (thus the ".Dump()" call)
*/
public static class MurMurHash3
{
	//Change to suit your needs
	const uint seed = 0;

	public static uint Hash(Stream stream)
	{
		const uint c1 = 0xcc9e2d51;
		const uint c2 = 0x1b873593;

		uint h1 = seed;
		uint k1 = 0;
		uint streamLength = 0;

		using (BinaryReader reader = new BinaryReader(stream))
		{
			byte[] chunk = reader.ReadBytes(4);
			while (chunk.Length > 0)
			{
				streamLength += (uint)chunk.Length;
				switch (chunk.Length)
				{
					case 4:
						/* Get four bytes from the input into an uint */
						k1 = (uint)
						   (chunk[0]
						  | chunk[1] << 8
						  | chunk[2] << 16
						  | chunk[3] << 24);

						/* bitmagic hash */
						k1 *= c1;
						k1 = rotl32(k1, 15);
						k1 *= c2;
						h1 ^= k1;

						h1 = rotl32(h1, 13);
						h1 = h1 * 5 + 0xe6546b64;
						break;
					case 3:
						k1 = (uint)
						   (chunk[0]
						  | chunk[1] << 8
						  | chunk[2] << 16);
						k1 *= c1;
						k1 = rotl32(k1, 15);
						k1 *= c2;
						h1 ^= k1;

						break;
					case 2:
						k1 = (uint)
						   (chunk[0]
						  | chunk[1] << 8);
						k1 *= c1;
						k1 = rotl32(k1, 15);
						k1 *= c2;
						h1 ^= k1;

						break;
					case 1:
						k1 = (uint)(chunk[0]);
						k1 *= c1;
						k1 = rotl32(k1, 15);
						k1 *= c2;
						h1 ^= k1;

						break;

				}
				chunk = reader.ReadBytes(4);
			}
		}

		// finalization, magic chants to wrap it all up
		h1 ^= streamLength;
		h1 = fmix(h1);

		return h1; // removed int conversion as we're going to be storing as uint
	}

	private static uint rotl32(uint x, byte r)
	{
		return (x << r) | (x >> (32 - r));
	}

	private static uint fmix(uint h)
	{
		// this part is easily reversed, just the exact same code
		h ^= h >> 16;

		h *= 0x85ebca6b;

		// this should be easy enough
		h ^= h >> 13;

		// this presents a more interesting problem, we have to find all possible components of this number
		
		h *= 0xc2b2ae35;
        // h = 0F9E3F7D
        // h * 0xc2b2ae35 = EC804C50

        // h =								   10101101100000001110010100010000 <- the input
        //  *=								   11000010101100101010111000110101	<- the constant
        //   =								   11101100100000000100110001010000 <- the value we have to reverse
        //  == 1000001111110100110001110100011011101100100000000100110001010000 <- what it would be without overflow 



        // this can be easily reversed by running the same code, as it takes the upper half & xors it into the lower half, which can be entirely reversed
        h ^= h >> 16; // 0x627C277 -> 0x627C450
		return h; // 0x627C450
	}
    static uint reverse_xorshift(uint input, int shift){
		// get the lower end that originally gets shifted & XOR'd into the input
		uint lower_component = input >> shift;
		// we then account for overlapping bits by calling another xor on them
		uint overlapping_bits = lower_component >> shift;
		// how would we account for if the bitcount was higher than 16?
		// xor all the componenets together
        return input ^ lower_component ^ overlapping_bits;
    }
}

// sample tagid = 0x627C450 (103269456)