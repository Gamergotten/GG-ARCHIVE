// rtc-data-client.js
// Minimal WebRTC client for data-only usage with WebSocket signaling.
// Replace SIGNALING_WS with your signaling server (wss:// for production).

const SIGNALING_WS = "wss://notification.svc.halowaypoint.com:443/hmcc/entities/NetworkId(16761467105662796034)";
const ICE_SERVERS = [{ urls: "turn:turn-mcc.trafficmanager.net:3478" }]; // BAD
/*
TransportRelayServers
turn:turn-mcc.trafficmanager.net:3478
turn:turn-mcc01.trafficmanager.net:3478
stun:COTURN.HW-USW-PROD.halowaypoint.com:3478
stun:COTURN.HW-USW01-PROD.halowaypoint.com:3478

UDSTransportRelayServers
stun:COTURN.HW-USW-PROD.halowaypoint.com:3478
stun:COTURN.HW-USW01-PROD.halowaypoint.com:3478
UDSAllowRelayCandidates false

HTTPS API response URL
dnsee38-1c668b36-95de-4627-b0d4-d3046d553f7c.southeastasia.cloudapp.azure.com

*/


/*

// 1) Your signaling send abstraction
async function sendSignal(message) {
  // Serialize and push via AMQP/WebSocket/etc.
  // Example: ws.send(JSON.stringify(message));
}

function onSignal(handler) {
  // Wire your transport's "message" to handler(JSON.parse(raw))
  // Example: ws.onmessage = (ev) => handler(JSON.parse(ev.data));
}

// 2) Set up PeerConnection and (optionally) a DataChannel
const pc = new RTCPeerConnection({
  iceServers: [
    { urls: ["stun:stun.l.google.com:19302"] } // Replace with your STUN/TURN
  ]
});

const dc = pc.createDataChannel("control", { negotiated: false });
dc.onopen = () => console.log("DataChannel open");
dc.onmessage = (ev) => console.log("RX:", ev.data);

// 3) Trickle ICE: emit candidates as they appear
pc.onicecandidate = (ev) => {
  if (!ev.candidate) return;
  sendSignal({
    type: "candidate",
    sessionId: "A89C8376-B546-4B09-AA96-793F23323F79",
    connectionId: "caller-123",
    candidate: ev.candidate
  });
};

// 4) Create and send the SDP offer
const offer = await pc.createOffer({
  offerToReceiveAudio: false,
  offerToReceiveVideo: false
});
await pc.setLocalDescription(offer);

await sendSignal({
  type: "offer",
  sessionId: "A89C8376-B546-4B09-AA96-793F23323F79",
  connectionId: "caller-123",
  sdp: offer.sdp
});

// 5) Handle inbound signaling (answer + remote candidates)
onSignal(async (msg) => {
  if (msg.type === "answer") {
    const remoteDesc = new RTCSessionDescription({ type: "answer", sdp: msg.sdp });
    await pc.setRemoteDescription(remoteDesc);
  } else if (msg.type === "candidate") {
    await pc.addIceCandidate(msg.candidate);
  }
});


*/



let ws = null;
let pc = null;
let dc = null;
let remoteName = null;
let pendingCandidates = [];

// Connect to signaling server
function connectSignaling() {
  ws = new WebSocket(SIGNALING_WS);

  //ws.addEventListener("open", () => sendSignal({ type: "login", name: myName }));
  ws.addEventListener("message", (evt) => {
    const msg = JSON.parse(evt.data);
    handleSignal(msg);
  });
  ws.addEventListener("close", () => console.log("Signaling closed"));
  ws.addEventListener("error", (e) => console.error("Signaling error", e));
}

function sendSignal(obj) {
  if (!ws || ws.readyState !== WebSocket.OPEN) {
    console.warn("Signaling socket not open");
    return;
  }
  ws.send(JSON.stringify(obj));
}

function createPeerConnection() {
  pc = new RTCPeerConnection({ iceServers: ICE_SERVERS });

  pc.addEventListener("icecandidate", (ev) => {
    if (ev.candidate && remoteName) sendSignal({ type: "candidate", candidate: ev.candidate, name: remoteName });
  });

  pc.addEventListener("connectionstatechange", () => {
    console.log("PC connectionState:", pc.connectionState);
  });

  // Remote-created datachannel handler (answerer side)
  pc.addEventListener("datachannel", (ev) => {
    setupDataChannel(ev.channel);
  });

  dc = pc.createDataChannel("ReliableDataChannel", { ordered: true });
  setupDataChannel(dc);

  return pc;
}

// Attach event handlers to a data channel
function setupDataChannel(channel) {
  channel.binaryType = "arraybuffer";
  channel.onopen = () => console.log("DataChannel open:", channel.label);
  channel.onclose = () => console.log("DataChannel closed:", channel.label);
  channel.onerror = (e) => console.error("DataChannel error:", e);
  channel.onmessage = (ev) => {
    handleIncomingData(ev.data, channel);
    
    console.log("recieved data from: ");
    console.log(channel);
    console.log(ev);
  };
  dc = channel;
}

// Send data with optional chunking for large payloads
function sendData(payload) {
  if (!dc || dc.readyState !== "open")
    throw new Error("DataChannel not open");
  
  dc.send(payload);
}


// Initiate a call (create offer)
async function callUser(targetName, { channelLabel = "data", reliable = false } = {}) {
  remoteName = targetName;
  createPeerConnection({ makeLocalChannel: true, channelLabel, reliable });
  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);
  sendSignal({ type: "offer", offer: pc.localDescription, name: remoteName });
}

// Handle incoming signaling messages
async function handleSignal(msg) {
  switch (msg.type) {
    case "offer":
      remoteName = msg.name;
      createPeerConnection({ makeLocalChannel: false });
      await pc.setRemoteDescription(msg.offer);
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      sendSignal({ type: "answer", answer: pc.localDescription, name: remoteName });
      break;

    case "answer":
      await pc.setRemoteDescription(msg.answer);
      break;

    case "candidate":
      if (pc && pc.remoteDescription && pc.remoteDescription.type) {
        try { await pc.addIceCandidate(msg.candidate); } catch (e) { console.warn(e); }
      } else {
        pendingCandidates.push(msg.candidate);
      }
      break;

    case "leave":
      closeConnection();
      break;

    default:
      console.warn("Unknown signal:", msg);
  }

  // drain pending candidates after remote desc set
  if (pc && pc.remoteDescription && pc.remoteDescription.type && pendingCandidates.length) {
    for (const c of pendingCandidates) {
      try { await pc.addIceCandidate(c); } catch (e) { console.warn(e); }
    }
    pendingCandidates = [];
  }
}

async function webrtc_main() {
  await connectSignaling();
  await callUser({ channelLabel: CHANNEL_LABEL, reliable: RELIABLE });

}

// run main immediately (remove call if you prefer manual invocation)
webrtc_main().catch((e) => console.error("main() failed:", e));