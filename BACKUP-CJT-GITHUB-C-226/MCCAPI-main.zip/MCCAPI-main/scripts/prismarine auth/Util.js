const nextUUID = () => UUID.v3({ namespace: '6ba7b811-9dad-11d1-80b4-00c04fd430c8', name: Date.now().toString() })

async function checkStatus(res) {
	if (res.ok) { // res.status >= 200 && res.status < 300
		return res.json()
	} else {
		const resp = await res.text()
		console.log('Request fail', resp)
		throw Error(`${res.status} ${res.statusText} ${resp}`)
	}
}

async function generateECKeyPair() {
	const keyPair = await crypto.subtle.generateKey(
		{
			name: "ECDSA", // or "ECDH" depending on your use case
			namedCurve: "P-256", // same curve as in Node.js
		},
		true, // extractable
		["sign", "verify"] // or ["deriveKey", "deriveBits"] for ECDH
	);

	return keyPair;
}

        function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms));}
		
function decodeAndDecompress(base64String) {
  // Step 1: Decode Base64 to binary
  const binaryString = atob(base64String);
  const binaryData = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    binaryData[i] = binaryString.charCodeAt(i);
  }

  // Step 2: Decompress using zlib (pako)
  const decompressedData = pako.inflate(binaryData);

  // Step 3: Convert Uint8Array to string
  const decodedText = new TextDecoder('utf-8').decode(decompressedData);
  return decodedText;
}

// URL-safe Base64 character set
const CHARSET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-";
function generateRandomString(length) {
    let result = "";
    const charsetLength = CHARSET.length;
    for (let i = 0; i < length; i++) {
        const randIndex = Math.floor(Math.random() * charsetLength);
		if (randIndex < 0 || randIndex >= charsetLength)
			randIndex = 0; // not to risk floating point error
		
        result += CHARSET[randIndex];
    }
    return result;
}

function uint64StringToBytesLE(str) {
  let value = BigInt(str);
  const out = new Uint8Array(8);

  for (let i = 0; i < 8; i++) {
    out[i] = Number(value & 0xFFn);
    value >>= 8n;
  }

  return out;
}

async function generateNetworkID(strUint64) {
  try {
    // Convert uint64 string → 8 bytes (little-endian)
    const dataToHash = uint64StringToBytesLE(strUint64);

    // "XBL-PC\0" as 7 bytes
    const secret = new Uint8Array([
      0x58, // X
      0x42, // B
      0x4C, // L
      0x2D, // -
      0x50, // P
      0x43, // C
      0x00  // null terminator
    ]);

    // Import the HMAC key
    const key = await crypto.subtle.importKey(
      "raw",
      secret,
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"]
    );

    // Compute HMAC
    const hashBuffer = await crypto.subtle.sign(
      "HMAC",
      key,
      dataToHash
    );

    let hash = new Uint8Array(hashBuffer); // 32 bytes

// Step 3: Overwrite first byte with 0x02 
  hash[0] = 0x02; 
  // Step 4: Read first 8 bytes as little-endian uint64 
  let value = 0n; 
  for (let i = 7; i >= 0; i--) { 
    value = (value << 8n) | BigInt(hash[i]); 
  } 
  // Step 5: Return decimal string return 
  return value.toString(10);
  // Step 5: Convert to hex string (16 chars, padded) 
  // const hex = value.toString(16).padStart(16, "0");
  // return hex;

  } catch (e) {
    return null;
  }
}
