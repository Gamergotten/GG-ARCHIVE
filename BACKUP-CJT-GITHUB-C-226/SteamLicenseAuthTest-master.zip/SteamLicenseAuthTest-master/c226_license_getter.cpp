// c226_license_getter.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#define _CRT_SECURE_NO_WARNINGS


#include <iostream>
#include "C:\Users\Joe bingle\Downloads\steamworks_sdk_163\sdk\public\steam\steam_api.h"

#include <chrono>
#include <thread>

using namespace std;

#include <iostream>
#include <vector>

#include <windows.h>
#include <wincrypt.h>
#pragma comment(lib, "Crypt32.lib")

std::string Base64Encode(const uint8_t* data, DWORD len)
{
    DWORD outLen = 0;

    // First call: get required buffer size
    CryptBinaryToStringA(data, len, CRYPT_STRING_BASE64 | CRYPT_STRING_NOCRLF, nullptr, &outLen);

    std::string out(outLen, '\0');

    // Second call: actually encode
    CryptBinaryToStringA(data, len, CRYPT_STRING_BASE64 | CRYPT_STRING_NOCRLF, (char*)(out.data()), &outLen);

    // Trim null terminator if present
    if (!out.empty() && out.back() == '\0')
        out.pop_back();

    return out;
}


class AuthTicketExample{
public:
    //AuthTicketExample(){
    AuthTicketExample() : m_CallbackAuthTicketResponse(this, &AuthTicketExample::OnGetAuthSessionTicketResponse) {
    }

    void RequestTicket()
    {
        std::cout << "Requesting Steam auth session ticket..." << std::endl;

        m_TicketBuffer.resize(1024); // Steam recommends ~1024 bytes

        m_TicketHandle = SteamUser()->GetAuthSessionTicket(
            m_TicketBuffer.data(),
            static_cast<int>(m_TicketBuffer.size()),
            &m_TicketSize,
            nullptr
        );

        if (m_TicketHandle == k_HAuthTicketInvalid)
        {
            std::cout << "Failed to request auth session ticket." << std::endl;
            return;
        }

        std::cout << "Ticket requested. Waiting for callback..." << std::endl;
    }

private:
    // Callback handler
    CCallback< AuthTicketExample, GetAuthSessionTicketResponse_t > m_CallbackAuthTicketResponse ;
    void OnGetAuthSessionTicketResponse(GetAuthSessionTicketResponse_t* pResponse);

    HAuthTicket m_TicketHandle = k_HAuthTicketInvalid;
    uint32 m_TicketSize = 0;
    std::vector<uint8> m_TicketBuffer;
};

void AuthTicketExample::OnGetAuthSessionTicketResponse(GetAuthSessionTicketResponse_t* pResponse)
{
    if (pResponse->m_eResult == k_EResultOK)
    {
        std::cout << "Auth ticket received successfully!" << std::endl;
        std::cout << "Ticket size: " << m_TicketSize << " bytes" << std::endl;

        // Print hex for debugging
        for (uint32 i = 0; i < m_TicketSize; i++)
            printf("%02X", m_TicketBuffer[i]);
        printf("\n");


        // Base64 encode using Windows API
        cout << "starting base64 encode...\n";
        std::string b64 = Base64Encode(m_TicketBuffer.data(), m_TicketSize);

        std::cout << "Base64 Ticket: " << b64 << "\n";
    }
    else
    {
        std::cout << "Auth ticket request failed. Error code: "
            << pResponse->m_eResult << std::endl;
    }
}


int main(){
    cout << "Hello World!\n";

    if (SteamAPI_RestartAppIfNecessary(k_uAppIdInvalid)) // Replace with your App ID
    {
        cout << "restarting! whoops this will open MCC;";
        return 1;
    }

    if (!SteamAPI_Init()) {
        cout << "failed to init steam!;";
        return 1;
    }

    AuthTicketExample example; 
    example.RequestTicket();


    while (true) {

        SteamAPI_RunCallbacks();
        this_thread::sleep_for(chrono::milliseconds(100));
    }

    SteamAPI_Shutdown(); 
    return 0;
}