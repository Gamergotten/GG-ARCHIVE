import zlib

dat_path = "D:\\Programs\\Steam\\userdata\\1259679492\\976730\\remote\\2535430211370706\\Saves\\AceSettings\\data"
output_path = "D:\\Programs\\Steam\\userdata\\1259679492\\976730\\remote\\2535430211370706\\Saves\\AceSettings\\data.json"

# Open the file in binary mode
with open(dat_path, "rb") as f:
    f.seek(44)  # Skip the first 32 bytes
    data = f.read()  # Read the rest of the file

# Decompress using zlib
try:
    decompressed = zlib.decompress(data)
    print("file decompressed.")
    test = decompressed.decode('utf-8', errors='replace')  # Replace errors if non-UTF-8
except zlib.error as e:
    print(f"Decompression failed: {e}")

# then write to file
try:
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(test)
except Exception as e:
    print(f"Failed to write to file: {e}")

print("json written.")