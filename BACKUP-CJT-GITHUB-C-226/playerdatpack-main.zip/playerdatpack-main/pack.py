import zlib
import hmac
import hashlib

def compute_hmac_sha256(data: bytes, key: bytes) -> bytes:
    return hmac.new(key, data, hashlib.sha256).digest()


# Paths
dat_path = "D:\\Programs\\Steam\\userdata\\1259679492\\976730\\remote\\2535430211370706\\Saves\\AceSettings\\data"
output_path = "D:\\Programs\\Steam\\userdata\\1259679492\\976730\\remote\\2535430211370706\\Saves\\AceSettings\\data.json"

# Step 1: Read the original .dat file to extract the 44-byte header
try:
    with open(dat_path, "rb") as f:
        header = f.read(12) # 44 bytes including the hash, but we can disregard that now that we generate our own!!
except Exception as e:
    print(f"Failed to read header from original file: {e}")
    exit(1)

# Step 2: Read the modified JSON content
try:
    with open(output_path, "r", encoding="utf-8") as f:
        json_text = f.read()
except Exception as e:
    print(f"Failed to read JSON file: {e}")
    exit(1)

# Step 3: Compress the modified content
try:
    compressed = zlib.compress(json_text.encode("utf-8"))
except Exception as e:
    print(f"Compression failed: {e}")
    exit(1)

# Step 4: Overwrite the original .dat file with header + compressed data
try:
    with open(dat_path, "wb") as f:
        f.write(header)
        f.write(compute_hmac_sha256(compressed, b"%#]t:$wwKMFGKe[Q@Hg+(m,PYyv+8QPr"))
        f.write(compressed)
    print("Successfully repacked and saved to original file.")
except Exception as e:
    print(f"Failed to write repacked data: {e}")
    exit(1)