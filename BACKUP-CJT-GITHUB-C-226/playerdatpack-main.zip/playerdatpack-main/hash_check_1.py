import hashlib
import hmac
import zlib

# Path to your binary data file
dat_path = "D:\\Programs\\Steam\\userdata\\1259679492\\976730\\remote\\2535430211370706\\Saves\\AceSettings\\data"

# Secret key
secret = b"%#]t:$wwKMFGKe[Q@Hg+(m,PYyv+8QPr"

# Hash functions using the secret as a key
hash_functions = {
    "HMAC-SHA256": lambda data: hmac.new(secret, data, hashlib.sha256).digest(),
    "HMAC-SHA1":   lambda data: hmac.new(secret, data, hashlib.sha1).digest(),
    "HMAC-MD5":    lambda data: hmac.new(secret, data, hashlib.md5).digest(),
    "HMAC-SHA512": lambda data: hmac.new(secret, data, hashlib.sha512).digest()[:32],
    "BLAKE2s (keyed)": lambda data: hashlib.blake2s(data, key=secret).digest(),
    "BLAKE2b (keyed)": lambda data: hashlib.blake2b(data, key=secret).digest()[:32],
}

try:
    with open(dat_path, "rb") as f:
        header = f.read(44)
        compressed_payload = f.read()

    stored_hash = header[12:44]
    print(f"Stored hash (offset 0x0C): {stored_hash.hex()}\n")

    found_match = False
    for name, func in hash_functions.items():
        computed = func(compressed_payload)
        match = computed == stored_hash
        print(f"{name}: {computed.hex()} {'✅ MATCH' if match else ''}")
        if match:
            found_match = True

    if not found_match:
        print("\n❌ No matching hash algorithm found.")
    else:
        print("\n✅ Hash algorithm identified.")

except Exception as e:
    print(f"Error: {e}")