import hashlib
import zlib

# Path to your binary data file
#dat_path = r"D:\Programs\Steam\userdata\1047739053\976730\remote\2535430211370706\Saves\AceSettings\data"
dat_path = "D:\\Programs\\Steam\\userdata\\1259679492\\976730\\remote\\2535430211370706\\Saves\\AceSettings\\data"

# Hash functions to test
hash_functions = {
    "SHA-256": lambda data: hashlib.sha256(data).digest(),
    "SHA-1":   lambda data: hashlib.sha1(data).digest(),
    "MD5":     lambda data: hashlib.md5(data).digest(),
    "SHA-512": lambda data: hashlib.sha512(data).digest()[:32],
    "BLAKE2s": lambda data: hashlib.blake2s(data).digest(),
    "BLAKE2b": lambda data: hashlib.blake2b(data).digest()[:32],
    "SHA3-256": lambda data: hashlib.sha3_256(data).digest(),
    "SHA3-512": lambda data: hashlib.sha3_512(data).digest()[:32],
}

try:
    with open(dat_path, "rb") as f:
        header = f.read(44)
        compressed_payload = f.read()

    stored_hash = header[12:44]
    print(f"Stored hash (offset 0x0C): {stored_hash.hex()}\n")

    # Decompress payload
    #try:
    #    decompressed = zlib.decompress(compressed_payload)
    #except zlib.error as e:
    #    print(f"❌ Decompression failed: {e}")
    #    exit(1)

    # Test each hash function on compressed data
    found_match = False
    for name, func in hash_functions.items():
        #computed = func(decompressed)
        computed = func(compressed_payload)
        match = computed == stored_hash
        print(f"{name}: {computed.hex()} {'✅ MATCH' if match else ''}")
        if match:
            found_match = True

    if not found_match:
        print("\n❌ No matching hash algorithm found.")
    else:
        print("\n✅ Hash algorithm identified.")

except Exception as e:
    print(f"Error: {e}")